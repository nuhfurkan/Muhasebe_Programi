﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MUHASEBE_prog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            

        }

        private void button6_Click(object sender, EventArgs e)
        {
          

        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            panel2.Visible = false;
            panel1.Visible = true;
            string[] caris;
            caris = Directory.GetDirectories(@"D:/muhasebe-prog/cariler/");
            int u=0;
            while (u < caris.Length)
            {
                
                comboBox1.Items.Add(caris[u].Replace("D:/muhasebe-prog/cariler/", ""));
                u++;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel4.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = true;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            panel5.Visible = false;
            panel4.Visible = false;
            panel6.Visible = false;
            panel3.Visible = true;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel4.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            panel6.Visible = false;
            panel5.Visible = true;
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(@"D:/muhasebe-prog/kasalar/" + textBox3.Text);
                  Directory.CreateDirectory(@"D:/muhasebe-prog/cariler/" + textBox5.Text);
            FileStream caribilgi = File.Create(@"D:/muhasebe-prog/cariler/" + textBox5.Text + "/" + textBox5.Text + "bilgi.txt");
            caribilgi.Close();

            FileStream bilgigir = new FileStream(@"D:/muhasebe-prog/cariler/" + textBox5.Text + "/" + textBox5.Text + "bilgi.txt",FileMode.Open,FileAccess.Write);
            StreamWriter bilgiyaz = new StreamWriter(bilgigir);
            bilgiyaz.WriteLine(textBox4.Text);
            if(checkBox3.Checked)
                bilgiyaz.WriteLine(textBox6.Text);
            else
                bilgiyaz.WriteLine("-" + textBox4.Text);
            bilgiyaz.Close();  }

        private void button12_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(@"D:/muhasebe-prog/cariler/" + textBox5.Text);
            FileStream caribilgi = File.Create(@"D:/muhasebe-prog/cariler/" + textBox5.Text + "/" + textBox5.Text + "bilgi.txt");
            caribilgi.Close();

            FileStream bilgigir = new FileStream(@"D:/muhasebe-prog/cariler/" + textBox5.Text + "/" + textBox5.Text + "bilgi.txt",FileMode.Open,FileAccess.Write);
            StreamWriter bilgiyaz = new StreamWriter(bilgigir);
            bilgiyaz.WriteLine(textBox4.Text);
            if(checkBox3.Checked)
                bilgiyaz.WriteLine(textBox6.Text);
            else
                bilgiyaz.WriteLine("-" + textBox4.Text);
            bilgiyaz.Close();

            MessageBox.Show("Kayit yapildi !");
            textBox4.Text = "";
            textBox5.Text = ""; textBox6.Text = "";
            checkBox4.Checked = false;
            checkBox3.Checked = false;

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            checkBox4.Checked = false;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            checkBox3.Checked = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Add("USD");
            comboBox2.Items.Add("EUR");
            comboBox2.Items.Add("RON");

        }
    }
}
