﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Muhasebe_prog_kurulum_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string a = "D:/muhasebe-prog";

        private void Form1_Load(object sender, EventArgs e)
        {
            //string[] dizin;
            //dizin = Directory.GetDirectories(@"D:/");
            //int i = (dizin.Length-1);
            //while(i!=0)
            //{
            //    listBox1.Items.Add(dizin[i]);
            //    if (dizin[i].Equals(a))
            //    {
            //        MessageBox.Show("Kurulum daha once yapilmis !!!");
            //        Application.Exit();

            //    }
            //    i--;
            //}
            //MessageBox.Show("kurulum yapilmamis");

            Directory.CreateDirectory(a);
            Directory.CreateDirectory(a + "/kasalar");
            Directory.CreateDirectory(a + "/gruplar");
            Directory.CreateDirectory(a + "/cariler");
            Directory.CreateDirectory(a + "/dovizler");

            MessageBox.Show("Kurulum basari ile yapildi !!!");

            Application.Exit();
                
            


        }

    }
}
